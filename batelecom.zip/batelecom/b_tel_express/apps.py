from django.apps import AppConfig


class B_tel_expressConfig(AppConfig):
    name = 'b_tel_express'
